import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.util.StringTokenizer;
import java.util.Scanner;
import java.io.File;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.StringTokenizer;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.sql.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Statement;

public class rough {

    public static void main(String args[]) {
        Connection c = null;
        Statement stmt = null;

        try {

            Class.forName("org.postgresql.Driver");
            c = DriverManager
                    .getConnection("jdbc:postgresql://localhost:5432/train_reservation_system",
                            "postgres", "shyam2672002");
            System.out.println("Opened database successfully");

            stmt = c.createStatement();

            String q = "select * from train where train.train_id=5750 AND train.doj='2023-05-27';";
            ResultSet rs ;
            rs = stmt.executeQuery(q);
            ResultSetMetaData rsmd;
            int columnsNumber;
            rsmd = rs.getMetaData();
            columnsNumber = rsmd.getColumnCount();
            String responseQuery="";
            while (rs.next()) {
                for (int i = 1; i <= columnsNumber; i++) {
                   
                        responseQuery = responseQuery + " ";
                    String columnValue = rs.getString(i);
                    // System.out.print(columnValue + " " + rsmd.getColumnName(i));
                    responseQuery += columnValue;
                }
                responseQuery = responseQuery + "\n";

            }
          System.out.println(responseQuery);

        } catch (Exception e) {

        }
    }

}